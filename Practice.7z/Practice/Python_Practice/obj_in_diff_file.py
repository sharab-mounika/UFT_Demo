import  python1


#obj2 = python1.test()       # we can create object for class which is in different file but we need to give file name
# # before obj and we need to import that file
#
# sum = obj2.add(100,100)
# print(sum)


# module is similar to python file which can have exceutable code , classes , functions etc
# executable code means code without any classes or functions or constructors simple print statements when we import any module it will execute executable code
# functions which are not in class are called module functions
# to access any functions in module --> modulename(filename).functionName()
# to access class members we need to create obj -- obj = modulename.classname()
# if module is in different directory then replace everywhere with direName.moduleName
# there is one more " from modulename import classname" ---> used to import particular class from particular module and if we use "import modulename" all classes will be imported


