# # This is used for commenting in python
#
# print("print is used to print on console")
#
# # to take use input use input
#
# i = input("enter your name")
# print("your name is"+i)
#
# # \ is used to say next line is continuation of that present line
#
# age = \
#     input("Enter your age")
# print(" your age is"+age)
#
# # ; is used to tell two sentence are different but are present in same line
#
# num = input("Enter your num"); print(" your number is"+num)
#
# # Python notes : 1)5 standard data types in python are number,string,list, tuple, dictionary 2)No need of declaring a
# # variable no need of assigning any datatype to it when we assign value to var it will automatically takes datatype
# #
#
# # use of ifelse

# num = int(input("Enter your num"))
# if(num>100):
#     print(" your number is greater than 100"+num)
# else:
#     print("number is less than 100")

# use of multiple conditions(if elseif else)

# num = int(input("Enter your num"))
# if(num<0):
#     print(" your number is negative")
# elif(num==0):
#     print(" your number is zero")
#
# elif(num%2==0):
#     print(" number is even")
# else:
#     print("number is odd")

# nested condition

# num = int(input("Enter your num"))
#
# if(num >= 0):
#     if(num%2 == 0):
#         print(" number is even")
#     else:
#         print("number is odd")
#
# else:
#     print("number is negative number")

# conditional OR and and also used in similar way and not

# num = int(input("Enter your num"))
# if (num > 100 or num < 0):
#     print(" number is invalid")
# elif num != 0:
#     print("number is not zero")

# Loops
# 1) with final range
# num = int(input("Enter your num"))
# for i in range(num):
#     print(i)
# # with initial and final range
# for i in range(1, 20):
#     print(str(num) +"*" + str(i) +"=" +str(num*i))
#     # typecasted for printing purpose as str and int cannot be concatenated
# # using increament or dec 3rd parameter will be inc or dec field
# for i in range(1, 20, 2):
#     print(i)
# for i in range(20, 2, -2):
#     print(i)
# #for loop  for list
# list1 = [1,2,3,4,5,6,7,8,7]
# for i in list1:
#     print(i)
#
# for i in 'testing':
#     print(i)
#
# li = [1,2,3,4]
# for i in li:
#     z=0
#     z=i+z
# print(z)
#
# # while loop
# num = int(input("Enter your num"))
# i=1
# while(i <= 10):
#     print(i * num)
#     i += 1   # i -= 1( for decrement

# break statement used to come out of loop on condition

# for i in range(1,10):
#     if(i ==5):
#         break
#     print(i)
#
# num = int(input("Enter your num"))
# for i in range(1,12):
#     if num*i == 60:
#         break
#     print(i*num)

# use of continue  if you want to skip remaining part of loop

# num = int(input("Enter your num"))
# for i in range(1,12):
#     if (num*i)%10 == 0:
#         continue
#     print(i*num)

# use of Else - what need to be executed once loop ends

# for i in range(1,12):
#     print(i)
# else:
#     print("loop ended")

# strings

# data = "testing world"
# print(data)
# data1 = 'myname is "mounika"'
# print(data1)
# data2 = "my name is 'mona'"
# print(data2)
# data3 = """
#             my name is mounika
#             my age is 25
#             my num is 8367688028 """
# print("my information is " + data3 * 2 + "\n" + "\t \t \t" + "Thanks you")
# * is used to print multiple times
# sub string fetching
emailAddress = " sharabmounika@gmail.com  "
# print(emailAddress[2])  # any index
# print(emailAddress[2:6])  # starting and ending index
# print(emailAddress[2:])    # giving only starting index
# print(emailAddress[:2])     # only ending index
# len  of string

# print(len(emailAddress))
# print(emailAddress.upper())
# print(emailAddress)
# print(emailAddress.lower())
# print(emailAddress.capitalize())  # capitalize first

# for removing spaces
# print(len(emailAddress))
# print(emailAddress)
# print(len(emailAddress.lstrip()))
# print(emailAddress)
# print(len(emailAddress.rstrip()))
# print(emailAddress)
# print(len(emailAddress.strip()))
# print(emailAddress)

# replace string

# email = "sharabmounika@gmail.com"
# print(email.replace("gmail", "yahoo"))
# print(email)
#
# # no of "a" in email
# length = 0
# for i in email:
#     if(i == 'a'):
#         length += 1
# print(length)
#  # or
# x= len(email)
# y= len(email.replace('a',""))
# print(x-y)
#
# # find one string in another  string
# mail="gmail"
# print(email.find(mail))  # it gives the position where this sub string or string is present in string  in which your are searching and returns -1 if there is no matching string
#
# # split function
#
# emailadd=" this is my gmail address is sharabmounika@gmail.com"
# list1 = emailadd.split(" ")
# print(len(list1))
# z=0
# for i in list1:
#     if i == 'is':
#         z += 1
# print(z)
#
# # comparing two strings
# # if case is nt same or there is some space in strings they will not be matched
#
# name1="testing"
# name2="Testing"
# name3=" testing"
# name4=" Testing"
#
# # to remove space and compare
# if name1.strip() == name3.strip():
#     print("compared")
# else:
#     print("not compared")
#
# # to makes two strings same and compare
# if name1.upper() == name2.upper():
#     print("compared")
# else:
#     print("not compared")
#
# #to remove spaces and make same cases
# if name1.upper().strip() == name4.upper().strip():
#         print("compared")
#
# # reversisng of string
# b = ""      # string initialisation
# length = len(name1)
# print(length)
# for i in range(length-1,-1,-1):# length gives the actual numbers of char but string index starts from 0 that's y  length-1
#     b = b+name1[i]
# print(b)
#
# # palendrome
# if name1 == b:
#     print("palendrome")
# else:
#     print("not a palendrome")

# Lists
# list can multiple data similar to array
# list can hold different datatype
# we can fetch data from list by passing index
# we can updata data in list
# we can insert or del data size increases or decreases automatically
list1 = [44, 67, 88, 99, "testing", 99]


# print(list1[4])
# print(list1[1:4])
# print(list1[1:])   # giving starting index
# print(list1[:4])    # giving ending index
# for i in list1:
#     print(i)
# # update any list value
# list1[3] = 100
# # add value to list
# list1.insert(3, "inserted")
# print(list1)
# # remove value if there are two values then it will remove only first value
# list1.remove(99)
# print(list1)
# print(len(list1))
# list2 = [22,88,99]
# list3 = list1 + list2
# print(list3)

# tuple
# everything is similar to list except we cannot change any value in tuple ( add, remove and update)

# tuple1 = (44,99,88,99,'monika')
#
# # fetching
# print(tuple1[2])
# a = len(tuple1)
# print(tuple1[:a])
# for i in tuple1:
#     print(i)
# for i in range(0,a):
#     print(tuple1[i])
#
# # we can find how time any feild is repeating using count
#
# print(tuple1.count(99))
#
# # to find index of any value
# print(tuple1.index(99))
#
# # merging two tuples
# tup2 = (33,77)
# tup3 = tuple1 + tup2
# print(tup3)

# dictionaries

# dictionaries stores value in the form of key-value pair. placed inside {} key must be always unique or if you
# create a duplicate key and given some value then this new value will be updated to old key. key and value can be of
# any datatype value can be fetched by passing its key

# dic1 = {"name":"mounika", "age":25, 3:"fav_number"}

# to fetch dic value you need to pass key

# print(dic1["name"])
#
# # to add values to dic
#
# dic1["company"] = "cap gemini"
#
# # to print dic
# print(dic1)     # print both key and value
# for i in dic1:  # print only values
#     print(i)
# one more method to print key
# print(dic1.keys())
# # to print only values
# print(dic1.values())
# # tone more menthod to fetch key and values
# print(dic1.items())
# # len of dic
# print(len(dic1))

# Functions main adv of functions is re-usability and to reduce duplicate  and to bring modularity in our code means
# we will be writing in small chunks and reuse them 1) fun without arg and return 2) fun with arg and without return
# 3) fun with arg and return 4) fun without arg and with return

# def testing1():
#     " this first line of function can be used for commenting no need of # here"
#     print("my name is mounika")


# testing1()  # calling the function
#
#
# def add(a, b):
#     sum = a + b
#     return sum
#
#
# def mul(c, d):
#     mul = c * d
#     return mul


# addition = add(10, 20)
# print(addition)
#
# multiplication = mul(addition, 10)
# print(multiplication)
#
# # fun with no arguments but with return
#
# def readdata():
#     data = 30
#     return  data
# x= readdata()
# print(x)

# different types of arguments

# required arguments
# def add(a,b):       # a.b are required arg need to be passed when calling the fun to perform that function
#     sum = a+b
#     print(sum)
# add(4,5)
#
# # keyword argu
#
# def add(a,b):
#     sum = a + b
#     print(sum)
#
#
# add(b=4, a=5)
#
# # default argu
# def add(a,b = 10):      # defult arguments must be always declared at the end
#     sum = a + b
#     print(sum)
#
#
# add(5)      # you can send b value as well it will update

# class
# python is a object oriented scripting language we can write our code in class
# class can have variables, function, constructors and constants
# we can access class members by creating object for it

# class testing:
#     def class_fun(self):  # function in class is defaulted by argument self
#         print(" this is class function")
#
#     def add(self, a, b):
#         sum = a + b
#         return sum


# we need to create obj of class to access its members

# obj = testing()
#
# # accessing fun of that class using obj
# obj.class_fun()
# x = obj.add(10, 20)
# print(x)


# constructors special type of method created with _init()_, first argument is always self automatically called when
# obj is created can take arguments constructors never returns value constructors are used for initialization kind of
# code you want put at start of class like initialization will be in constructor eg if there are three methods for
# getting three values from data base if there is no constructor we need write data base connection code for all
# three methods for gettig three values . suppose there is constructor we can include database connection code in
# constructor which will be executed at start of the class it is like initialization for the class

# class B:
#     def __init__(self, a, b):
#         print("This is a constructor")
#         c = a + b
#         print(c)
#
#     def add(self, a, b):
#         sum = a + b
#         return sum
#
#
# obj1 = B(10, 20)  # Passing arg for constructor while creating object
#
# class test:
#     def add(self, a, b):
#         sum = a + b
#         return sum

# exceptions
# while executing any code if we get any error in runtime, this type of error is called  runtime error or logical error or exception task we are performing when we get exception is called exception handling
try:
     input1 = int(input("enter a number"))
     input2 = int(input("enter a number"))
     sum = input1+input2
     print(sum)
except:
     print(" your input is not correct please give numbers")

finally:
    print("as this is in finally this will be executed irrespective of exception ")


