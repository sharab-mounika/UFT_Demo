import requests         # as we need to send a request to api we need request package
import json             # to parse to json format
import  jsonpath        # to validate json

# to change dic to json

# dic = '{"name":"mounika","age":"25","city":"hyderabad"}'
#
# json_result = json.loads(dic)   # json.load will parse dic to json
# print(json_result)

api_url ="https://reqres.in/api/users?page=2"

# make a request
response1 = requests.get(api_url)
print(response1.text)

# validate response
assert response1.status_code==200

# parse to json
json_response=json.loads(response1.text)
print(json_response)
# output of json_response is {'page': 2, 'per_page': 6, 'total': 12, 'total_pages': 2, 'data': [{'id': 7, 'email': 'michael.lawson@reqres.in', 'first_name': 'Michael', 'last_name': 'Lawson', 'avatar': 'https://s3.amazonaws.com/uifaces/faces/twitter/follettkyle/128.jpg'}, {'id': 8, 'email': 'lindsay.ferguson@reqres.in', 'first_name': 'Lindsay', 'last_name': 'Ferguson', 'avatar': 'https://s3.amazonaws.com/uifaces/faces/twitter/araa3185/128.jpg'}, {'id': 9, 'email': 'tobias.funke@reqres.in', 'first_name': 'Tobias', 'last_name': 'Funke', 'avatar': 'https://s3.amazonaws.com/uifaces/faces/twitter/vivekprvr/128.jpg'}, {'id': 10, 'email': 'byron.fields@reqres.in', 'first_name': 'Byron', 'last_name': 'Fields', 'avatar': 'https://s3.amazonaws.com/uifaces/faces/twitter/russoedu/128.jpg'}, {'id': 11, 'email': 'george.edwards@reqres.in', 'first_name': 'George', 'last_name': 'Edwards', 'avatar': 'https://s3.amazonaws.com/uifaces/faces/twitter/mrmoiree/128.jpg'}, {'id': 12, 'email': 'rachel.howell@reqres.in', 'first_name': 'Rachel', 'last_name': 'Howell', 'avatar': 'https://s3.amazonaws.com/uifaces/faces/twitter/hebertialmeida/128.jpg'}], 'ad': {'company': 'StatusCode Weekly', 'url': 'http://statuscode.org/', 'text': 'A weekly newsletter focusing on software development, infrastructure, the server, performance, and the stack end of things.'}}


# to validate json install json path  command - "pip install jsonpath"
# use https://jsonformatter.curiousconcept.com/  paste the result of json there

# apply json path
x = jsonpath.jsonpath(json_response,'total')     # jsonpath module and jsonpath method  searching specific element total in json
print(x[0])             # of zero index
y = jsonpath.jsonpath(json_response,'data[0].first_name')       # data is an array [0] going into array first index element which is object in that selecting  firstname
print(y[0])

z = jsonpath.jsonpath(json_response,'data')     # prints array values
print(z)

# if we want to print all first names of all objects in the array data
for val in json_response['data']:
    # print(val['first_name'])
    print(val)                  # prints all array value


