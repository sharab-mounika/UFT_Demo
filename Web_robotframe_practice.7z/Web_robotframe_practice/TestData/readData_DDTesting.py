import openpyxl

wb = openpyxl.load_workbook("C:/Users/shmounik/PycharmProjects/read_ddtesting.xlsx")


def fetch_cell_data(sheetname, row, column):
    sh = wb[sheetname]
    cell = sh.cell(int(row), int(column))
    return cell.value


def fetch_no_of_rows(sheetname):
    sh = wb[sheetname]
    return sh.max_row


x = fetch_cell_data("Sheet1", 1, 1)
print(x)


rows = fetch_no_of_rows("Sheet1")
print(rows)
