# note run command - pip install openpyxl    to install the package
import openpyxl

# load work book
#wb = openpyxl.load_workbook("C:\\xcel\\xcel_practice.xlsx")
# print(wb.sheetnames)
#
# # create obj of sheet on which you want to work on
#
# sh = wb['Sheet1']
# print(sh.title)
# print(sh['B4'].value)
#
# # use can also create obj for cell to fetch the value
#
# cl = sh.cell(5, 2)
#print(cl.value)
# print(cl.row)
# print(cl.column)

# reading complete data from excel
# need to find no of rows and columns first
# rows = sh.max_row
# columns = sh.max_column
# print(rows)
# print(columns)

# for i in range(1, rows + 1):
#     for j in range(1, columns + 1):
#         c = sh.cell(i, j)
#         # c= sh.cell(row=i,column=j)
#         print(c.value)
# for r in sh['A1':'B5']:   # even brackets matters here orelse it will throw error
#     for c in r:
#         print(c.value)

# writing to excel
wb = openpyxl.Workbook()
sh = wb.active
sh.title="ToWrite"
print(sh.title)
sh['A6'].value = "testing"
# creating a sheet
wb.create_sheet(title="testing")
sh1 = wb['testing']
sh1['A3'] = "mounika"
#to remove any sheet ToWrite
wb.remove_sheet(wb['ToWrite'])
wb.save("C:\\xcel\\xcel_write.xlsx")    # it will create and excel and save above activities there

